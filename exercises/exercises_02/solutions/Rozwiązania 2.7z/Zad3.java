public class Zad3 {
  public static void main(String[] args) {
    // wszelkie ciągi znaków (stringi) muszą znaleźć się w podwójnym cudzysłowiu
    // do wypisywania instrukcji służy następujące polecenie:
    System.out.println("Hello world!");    
  }
}
