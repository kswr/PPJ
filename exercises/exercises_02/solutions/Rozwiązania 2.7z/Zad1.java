// nazwa klasy musi być taka sama jak nazwa pliku
public class Zad1 {
  
  // jako pierwsza uruchamiana jest metoda main o podanej sygnaturze
  public static void main(String[] args) {
    // nasza metoda nie robi nic, więc efekt działania programu nie będzie imponujący
  }
}
